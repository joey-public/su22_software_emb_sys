1. Execute `sudo ./1-as-wes237b`
2. Execute `sudo passwd root`
3. Reboot

At this point, make sure that you do not login again as wes-237b until instructed to.

4. ssh in with `ssh root@192.168.55.1`
5. Insert the SD Card into the Jetson
6. Execute `./2-as-root`
7. Reboot

It is now safe to log in as wes-237b again.

8. Finally `rm -rf /home2`
